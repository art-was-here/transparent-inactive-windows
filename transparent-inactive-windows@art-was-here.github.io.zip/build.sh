#!/bin/bash

# Build script for Transparent Inactive Windows GNOME Extension

EXTENSION_UUID="transparent-inactive-windows@art-was-here.github.io"
EXTENSION_DIR="$HOME/.local/share/gnome-shell/extensions/$EXTENSION_UUID"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Compile GSettings schemas
compile_schemas() {
    print_status "Compiling GSettings schemas..."
    if command_exists glib-compile-schemas; then
        glib-compile-schemas schemas/
        print_status "Schemas compiled successfully"
    else
        print_warning "glib-compile-schemas not found. Please install glib2-tools"
        print_warning "On Ubuntu/Debian: sudo apt install glib2-tools"
        print_warning "On Fedora: sudo dnf install glib2-tools"
        return 1
    fi
}

# Install the extension
install_extension() {
    print_status "Installing extension..."
    compile_schemas
    
    mkdir -p "$EXTENSION_DIR"
    cp -r * "$EXTENSION_DIR/"
    print_status "Extension installed to $EXTENSION_DIR"
}

# Uninstall the extension
uninstall_extension() {
    print_status "Uninstalling extension..."
    if [ -d "$EXTENSION_DIR" ]; then
        rm -rf "$EXTENSION_DIR"
        print_status "Extension uninstalled"
    else
        print_warning "Extension directory not found"
    fi
}

# Enable the extension
enable_extension() {
    print_status "Enabling extension..."
    if command_exists gnome-extensions; then
        gnome-extensions enable "$EXTENSION_UUID"
        print_status "Extension enabled"
    else
        print_error "gnome-extensions command not found"
    fi
}

# Disable the extension
disable_extension() {
    print_status "Disabling extension..."
    if command_exists gnome-extensions; then
        gnome-extensions disable "$EXTENSION_UUID"
        print_status "Extension disabled"
    else
        print_error "gnome-extensions command not found"
    fi
}

# Show extension status
show_status() {
    print_status "Extension status:"
    if command_exists gnome-extensions; then
        gnome-extensions list | grep "$EXTENSION_UUID" || print_warning "Extension not found"
    else
        print_error "gnome-extensions command not found"
    fi
}

# Update translation template
update_pot() {
    print_status "Updating translation template..."
    if command_exists xgettext; then
        xgettext --from-code=UTF-8 \
            --keyword=_ \
            --output=po/transparent-inactive-windows.pot \
            extension.js prefs.js
        print_status "Translation template updated"
    else
        print_error "xgettext not found. Please install gettext"
    fi
}

# Show help
show_help() {
    echo "Usage: $0 [COMMAND]"
    echo ""
    echo "Commands:"
    echo "  install      - Install the extension"
    echo "  uninstall    - Uninstall the extension"
    echo "  enable       - Enable the extension"
    echo "  disable      - Disable the extension"
    echo "  compile      - Compile GSettings schemas"
    echo "  status       - Show extension status"
    echo "  update-pot   - Update translation template"
    echo "  help         - Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 install"
    echo "  $0 enable"
    echo "  $0 status"
}

# Main script logic
case "$1" in
    install)
        install_extension
        ;;
    uninstall)
        uninstall_extension
        ;;
    enable)
        enable_extension
        ;;
    disable)
        disable_extension
        ;;
    compile)
        compile_schemas
        ;;
    status)
        show_status
        ;;
    update-pot)
        update_pot
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        print_error "Unknown command: $1"
        echo ""
        show_help
        exit 1
        ;;
esac 